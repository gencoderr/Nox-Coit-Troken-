
import React, { useState, useCallback } from 'react';
import type { PropertyDetails, GeneratedContent } from './types';
import { generateRealEstateAnalysis } from './services/geminiService';
import InputForm from './components/InputForm';
import ResultsDisplay from './components/ResultsDisplay';
import Window from './components/Window';

const App: React.FC = () => {
  const [propertyDetails, setPropertyDetails] = useState<PropertyDetails>({
    purchasePrice: 300000,
    downPayment: 60000,
    interestRate: 6.5,
    loanTerm: 30,
    monthlyRent: 2500,
    propertyTaxes: 3600,
    insurance: 1200,
    maintenance: 250,
    hoa: 0,
  });
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalysis = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);
    try {
      const content = await generateRealEstateAnalysis(propertyDetails);
      setGeneratedContent(content);
    } catch (err) {
      setError(err instanceof Error ? `An error occurred: ${err.message}` : 'An unknown error occurred.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [propertyDetails]);

  return (
    <main className="bg-[#0d1117] min-h-screen text-gray-300 p-4 sm:p-6 lg:p-8 flex items-center justify-center font-sans">
      <div className="w-full max-w-7xl">
        <Window title="AI Real Estate Resource Generator">
          <div className="flex flex-col lg:flex-row gap-8 p-6 bg-[#161b22]/80 backdrop-blur-sm h-full">
            <div className="lg:w-1/3 lg:pr-8 lg:border-r border-gray-700/50 flex flex-col">
              <h2 className="text-xl font-bold text-cyan-400 mb-4">Property Details</h2>
              <p className="text-sm text-gray-400 mb-6">Enter the specifics of your potential investment property. The AI will generate a detailed analysis based on this data.</p>
              <div className="flex-grow overflow-y-auto pr-2">
                <InputForm
                  propertyDetails={propertyDetails}
                  setPropertyDetails={setPropertyDetails}
                  isLoading={isLoading}
                />
              </div>
              <button
                onClick={handleAnalysis}
                disabled={isLoading}
                className="mt-6 w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center justify-center shadow-lg shadow-cyan-500/20"
              >
                {isLoading ? 'Generating...' : 'Generate Resources'}
              </button>
            </div>
            <div className="lg:w-2/3 flex flex-col">
              <h2 className="text-xl font-bold text-purple-400 mb-4">Generated Resources</h2>
              <p className="text-sm text-gray-400 mb-6">Review the AI-powered analysis, task lists, and professional tips for your investment.</p>
              <div className="flex-grow bg-black/20 rounded-lg border border-gray-700/50">
                <ResultsDisplay
                  content={generatedContent}
                  isLoading={isLoading}
                  error={error}
                />
              </div>
            </div>
          </div>
        </Window>
      </div>
    </main>
  );
};

export default App;
