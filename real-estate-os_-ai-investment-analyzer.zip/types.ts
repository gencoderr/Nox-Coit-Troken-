export interface PropertyDetails {
  purchasePrice: number;
  downPayment: number;
  interestRate: number;
  loanTerm: number;
  monthlyRent: number;
  propertyTaxes: number;
  insurance: number;
  maintenance: number;
  hoa: number;
}

export interface Metric {
  name: string;
  value: string;
  explanation: string;
}

export interface InvestmentAnalysis {
  summary: string;
  metrics: Metric[];
}

export interface ManagementTasks {
  initial: string[];
  ongoing: string[];
}

export interface MarketAnalysis {
  trends: string;
  risks: string;
  opportunities: string;
}

export interface DigitalAsset {
  projectName: string;
  tokenTicker: string;
  coreConcept: string;
  networkArchitecture: string;
}

export interface GeneratedContent {
  analysis: InvestmentAnalysis;
  tasks: ManagementTasks;
  tips: string[];
  market: MarketAnalysis;
  digitalAsset: DigitalAsset;
}
