
import React from 'react';
import type { ReactNode } from 'react';
import { XIcon } from './icons/XIcon';
import { MinimizeIcon } from './icons/MinimizeIcon';
import { MaximizeIcon } from './icons/MaximizeIcon';

interface WindowProps {
  title: string;
  children: ReactNode;
}

const Window: React.FC<WindowProps> = ({ title, children }) => {
  return (
    <div className="bg-[#1c2128] border border-gray-700 rounded-lg shadow-2xl shadow-black/50 w-full h-[90vh] max-h-[1000px] flex flex-col overflow-hidden">
      <header className="flex items-center justify-between bg-[#2d333b] px-4 py-2 border-b border-gray-700 select-none">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
        </div>
        <h1 className="text-sm font-semibold text-gray-300">{title}</h1>
        <div className="flex items-center gap-2 text-gray-400">
          <MinimizeIcon className="w-4 h-4" />
          <MaximizeIcon className="w-4 h-4" />
          <XIcon className="w-4 h-4" />
        </div>
      </header>
      <div className="flex-grow overflow-y-auto">
        {children}
      </div>
    </div>
  );
};

export default Window;
