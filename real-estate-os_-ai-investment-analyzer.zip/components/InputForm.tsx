
import React from 'react';
import type { PropertyDetails } from '../types';

interface InputFormProps {
  propertyDetails: PropertyDetails;
  setPropertyDetails: React.Dispatch<React.SetStateAction<PropertyDetails>>;
  isLoading: boolean;
}

interface FormField {
  id: keyof PropertyDetails;
  label: string;
  type: 'number';
  prefix?: string;
  suffix?: string;
}

const formFields: FormField[] = [
  { id: 'purchasePrice', label: 'Purchase Price', type: 'number', prefix: '$' },
  { id: 'downPayment', label: 'Down Payment', type: 'number', prefix: '$' },
  { id: 'interestRate', label: 'Interest Rate', type: 'number', suffix: '%' },
  { id: 'loanTerm', label: 'Loan Term (Years)', type: 'number' },
  { id: 'monthlyRent', label: 'Gross Monthly Rent', type: 'number', prefix: '$' },
  { id: 'propertyTaxes', label: 'Annual Property Taxes', type: 'number', prefix: '$' },
  { id: 'insurance', label: 'Annual Insurance', type: 'number', prefix: '$' },
  { id: 'maintenance', label: 'Monthly Maintenance', type: 'number', prefix: '$' },
  { id: 'hoa', label: 'Monthly HOA Fees', type: 'number', prefix: '$' },
];

const InputField: React.FC<{
  field: FormField;
  value: number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled: boolean;
}> = ({ field, value, onChange, disabled }) => (
  <div>
    <label htmlFor={field.id} className="block text-sm font-medium text-gray-400 mb-1">{field.label}</label>
    <div className="relative">
      {field.prefix && <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">{field.prefix}</span>}
      <input
        type={field.type}
        id={field.id}
        name={field.id}
        value={value}
        onChange={onChange}
        disabled={disabled}
        className={`w-full bg-[#0d1117] border border-gray-600 rounded-md py-2 text-gray-300 focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200 ${field.prefix ? 'pl-7' : 'pl-3'} ${field.suffix ? 'pr-8' : 'pr-3'}`}
      />
      {field.suffix && <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500">{field.suffix}</span>}
    </div>
  </div>
);


const InputForm: React.FC<InputFormProps> = ({ propertyDetails, setPropertyDetails, isLoading }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPropertyDetails(prev => ({
      ...prev,
      [name]: value === '' ? '' : Number(value),
    }));
  };

  return (
    <form onSubmit={(e) => e.preventDefault()} className="space-y-4">
      {formFields.map((field) => (
        <InputField
          key={field.id}
          field={field}
          value={propertyDetails[field.id]}
          onChange={handleChange}
          disabled={isLoading}
        />
      ))}
    </form>
  );
};

export default InputForm;
