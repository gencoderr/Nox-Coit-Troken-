import React, { useState } from 'react';
import type { GeneratedContent } from '../types';
import TabButton from './TabButton';
import Loader from './Loader';
import { CalculatorIcon } from './icons/CalculatorIcon';
import { ChecklistIcon } from './icons/ChecklistIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { TrendingUpIcon } from './icons/TrendingUpIcon';
import { SatelliteIcon } from './icons/SatelliteIcon';

interface ResultsDisplayProps {
  content: GeneratedContent | null;
  isLoading: boolean;
  error: string | null;
}

type Tab = 'analysis' | 'tasks' | 'tips' | 'market' | 'digitalAsset';

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ content, isLoading, error }) => {
  const [activeTab, setActiveTab] = useState<Tab>('analysis');

  if (isLoading) {
    return <div className="flex flex-col items-center justify-center h-full p-6 text-center"><Loader /><p className="mt-4 text-gray-400">AI is analyzing your investment...</p></div>;
  }

  if (error) {
    return <div className="flex items-center justify-center h-full p-6 text-center text-red-400"><p>{error}</p></div>;
  }

  if (!content) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center">
        <div className="w-16 h-16 bg-gray-800/50 rounded-full flex items-center justify-center border-2 border-dashed border-gray-600 mb-4">
            <CalculatorIcon className="w-8 h-8 text-gray-500" />
        </div>
        <h3 className="text-lg font-semibold text-gray-300">Awaiting Analysis</h3>
        <p className="text-gray-500 mt-1">Your generated resources will appear here.</p>
      </div>
    );
  }

  return (
    <div className="p-6 h-full flex flex-col">
      <div className="flex border-b border-gray-700 mb-4 overflow-x-auto">
        <TabButton isActive={activeTab === 'analysis'} onClick={() => setActiveTab('analysis')}>
          <CalculatorIcon className="w-5 h-5 mr-2" />
          Analysis
        </TabButton>
        <TabButton isActive={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')}>
          <ChecklistIcon className="w-5 h-5 mr-2" />
          Tasks
        </TabButton>
        <TabButton isActive={activeTab === 'tips'} onClick={() => setActiveTab('tips')}>
          <LightbulbIcon className="w-5 h-5 mr-2" />
          Pro Tips
        </TabButton>
        <TabButton isActive={activeTab === 'market'} onClick={() => setActiveTab('market')}>
          <TrendingUpIcon className="w-5 h-5 mr-2" />
          Market Insights
        </TabButton>
        <TabButton isActive={activeTab === 'digitalAsset'} onClick={() => setActiveTab('digitalAsset')}>
          <SatelliteIcon className="w-5 h-5 mr-2" />
          Asset Digitization
        </TabButton>
      </div>
      <div className="flex-grow overflow-y-auto pr-2">
        {activeTab === 'analysis' && (
          <div>
            <p className="text-gray-400 mb-6 italic">{content.analysis.summary}</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {content.analysis.metrics.map(metric => (
                <div key={metric.name} className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                  <h4 className="font-semibold text-cyan-400">{metric.name}</h4>
                  <p className="text-2xl font-bold text-white my-1">{metric.value}</p>
                  <p className="text-sm text-gray-400">{metric.explanation}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        {activeTab === 'tasks' && (
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex-1">
              <h4 className="text-lg font-semibold mb-3 text-purple-400">Initial Setup Tasks</h4>
              <ul className="space-y-2">
                {content.tasks.initial.map((task, i) => (
                  <li key={i} className="flex items-start bg-gray-800/50 p-3 rounded-md">
                    <ChecklistIcon className="w-5 h-5 text-green-400 mt-1 mr-3 flex-shrink-0" />
                    <span>{task}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex-1">
              <h4 className="text-lg font-semibold mb-3 text-purple-400">Ongoing Management</h4>
              <ul className="space-y-2">
                {content.tasks.ongoing.map((task, i) => (
                  <li key={i} className="flex items-start bg-gray-800/50 p-3 rounded-md">
                    <ChecklistIcon className="w-5 h-5 text-green-400 mt-1 mr-3 flex-shrink-0" />
                    <span>{task}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
        {activeTab === 'tips' && (
          <div className="space-y-4">
            {content.tips.map((tip, i) => (
              <div key={i} className="flex items-start bg-gray-800/50 p-4 rounded-lg">
                <LightbulbIcon className="w-6 h-6 text-yellow-400 mt-1 mr-4 flex-shrink-0" />
                <p>{tip}</p>
              </div>
            ))}
          </div>
        )}
        {activeTab === 'market' && content.market && (
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-semibold mb-2 text-orange-400">Market Trends</h4>
              <p className="bg-gray-800/50 p-4 rounded-md text-gray-300">{content.market.trends}</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-orange-400">Potential Risks</h4>
              <p className="bg-gray-800/50 p-4 rounded-md text-gray-300">{content.market.risks}</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-orange-400">Opportunities</h4>
              <p className="bg-gray-800/50 p-4 rounded-md text-gray-300">{content.market.opportunities}</p>
            </div>
          </div>
        )}
         {activeTab === 'digitalAsset' && content.digitalAsset && (
          <div className="space-y-6">
            <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                <h3 className="text-2xl font-bold text-yellow-400">{content.digitalAsset.projectName}</h3>
                <p className="text-lg text-gray-400 font-mono">{content.digitalAsset.tokenTicker}</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2 text-yellow-400">Core Concept</h4>
              <p className="bg-gray-800/50 p-4 rounded-md text-gray-300">{content.digitalAsset.coreConcept}</p>
            </div>
             <div>
              <h4 className="text-lg font-semibold mb-2 text-yellow-400">Network Architecture</h4>
              <p className="bg-gray-800/50 p-4 rounded-md text-gray-300">{content.digitalAsset.networkArchitecture}</p>
            </div>
             <p className="text-xs text-center text-gray-500 pt-4">Disclaimer: This is a fictional simulation for creative exploration only and does not constitute financial or technical advice.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultsDisplay;
