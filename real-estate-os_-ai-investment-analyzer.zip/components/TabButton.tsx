import React from 'react';
import type { ReactNode } from 'react';

interface TabButtonProps {
  isActive: boolean;
  onClick: () => void;
  children: ReactNode;
}

const TabButton: React.FC<TabButtonProps> = ({ isActive, onClick, children }) => {
  return (
    <button
      onClick={onClick}
      className={`flex items-center px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200 focus:outline-none whitespace-nowrap ${
        isActive
          ? 'bg-gray-800/50 border-x border-t border-gray-700 text-cyan-400'
          : 'text-gray-400 hover:bg-gray-800/30'
      }`}
    >
      {children}
    </button>
  );
};

export default TabButton;