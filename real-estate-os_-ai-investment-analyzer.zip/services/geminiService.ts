import { GoogleGenAI, Type } from "@google/genai";
import type { PropertyDetails, GeneratedContent } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const schema = {
  type: Type.OBJECT,
  properties: {
    analysis: {
      type: Type.OBJECT,
      properties: {
        summary: {
          type: Type.STRING,
          description: "A concise summary paragraph evaluating the overall potential of this investment, highlighting its strengths and weaknesses."
        },
        metrics: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "Name of the financial metric." },
              value: { type: Type.STRING, description: "Calculated value of the metric (e.g., '$150.25/month', '8.5%')." },
              explanation: { type: Type.STRING, description: "A brief explanation of what the metric means." }
            },
            required: ["name", "value", "explanation"]
          },
          description: "An array of key financial metrics."
        }
      },
      required: ["summary", "metrics"]
    },
    tasks: {
      type: Type.OBJECT,
      properties: {
        initial: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "A checklist of initial, one-time tasks for a new landlord setting up this property."
        },
        ongoing: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "A checklist of ongoing, recurring tasks for managing the property."
        }
      },
      required: ["initial", "ongoing"]
    },
    tips: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of 3-5 actionable tips and best practices for a new landlord."
    },
    market: {
        type: Type.OBJECT,
        properties: {
            trends: { type: Type.STRING, description: "A paragraph summarizing current local and broader market trends relevant to this property type and location." },
            risks: { type: Type.STRING, description: "A paragraph outlining potential market-related risks (e.g., interest rate changes, market saturation, economic downturn)." },
            opportunities: { type: Type.STRING, description: "A paragraph identifying potential opportunities based on market conditions (e.g., upcoming developments, demographic shifts)." }
        },
        required: ["trends", "risks", "opportunities"]
    },
    digitalAsset: {
        type: Type.OBJECT,
        properties: {
            projectName: { type: Type.STRING, description: "A professional and futuristic-sounding project name for the asset digitization (e.g., 'Terra Firma Digital', 'Project Apollo Estates')." },
            tokenTicker: { type: Type.STRING, description: "A 3-5 character stock market-style ticker symbol for the token, starting with a dollar sign (e.g., '$TFD', '$AEST')." },
            coreConcept: { type: Type.STRING, description: "A paragraph explaining the core value proposition of digitizing this asset, such as enabling fractional ownership or creating a transparent record of ownership on a fictional blockchain." },
            networkArchitecture: { type: Type.STRING, description: "A creative, high-level paragraph describing a fictional decentralized network. It should include the concepts of 'ground-based root nodes' for local validation and a 'satellite constellation' for global consensus and data redundancy." }
        },
        required: ["projectName", "tokenTicker", "coreConcept", "networkArchitecture"]
    }
  },
  required: ["analysis", "tasks", "tips", "market", "digitalAsset"]
};


export const generateRealEstateAnalysis = async (details: PropertyDetails): Promise<GeneratedContent> => {
  const prompt = `
    You are a sophisticated real estate investment analysis AI. Based on the following property data, provide a comprehensive analysis.

    Property Data:
    - Purchase Price: $${details.purchasePrice.toLocaleString()}
    - Down Payment: $${details.downPayment.toLocaleString()}
    - Interest Rate: ${details.interestRate}%
    - Loan Term: ${details.loanTerm} years
    - Gross Monthly Rent: $${details.monthlyRent.toLocaleString()}
    - Annual Property Taxes: $${details.propertyTaxes.toLocaleString()}
    - Annual Insurance: $${details.insurance.toLocaleString()}
    - Monthly Maintenance/Vacancy Estimate: $${details.maintenance.toLocaleString()}
    - Monthly HOA Fees: $${details.hoa.toLocaleString()}

    Your tasks:
    1.  Calculate key financial metrics and provide a qualitative summary.
    2.  Generate a market insights report.
    3.  Act as a futuristic fintech architect to devise a *fictional asset digitization plan* for this property. This is for creative exploration. The plan should include a decentralized network with ground 'root' nodes and a 'satellite' constellation.

    Your entire response must be in a structured JSON format that strictly adheres to the provided schema.

    Calculation Guidance:
    - Loan Amount = Purchase Price - Down Payment
    - Monthly P&I: Use standard mortgage calculation.
    - Total Monthly Expenses = Monthly P&I + (Annual Taxes / 12) + (Annual Insurance / 12) + Monthly Maintenance + Monthly HOA
    - Monthly Cash Flow = Gross Monthly Rent - Total Monthly Expenses
    - Cap Rate = (Annual Net Operating Income / Purchase Price) * 100. (NOI = Annual Rent - Annual Expenses excluding mortgage)
    - Cash-on-Cash Return = ((Monthly Cash Flow * 12) / Down Payment) * 100

    Generate the JSON output now.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.3,
      },
    });

    const jsonText = response.text.trim();
    // It is already a string, but we need to parse it to get a JS object.
    const parsedJson = JSON.parse(jsonText);
    return parsedJson as GeneratedContent;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate real estate analysis from the AI model.");
  }
};
