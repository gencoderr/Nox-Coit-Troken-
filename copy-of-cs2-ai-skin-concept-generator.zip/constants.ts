
import type { Weapon } from './types';

export const WEAPONS: Weapon[] = [
  { id: 'ak-47', name: 'AK-47' },
  { id: 'm4a4', name: 'M4A4' },
  { id: 'm4a1-s', name: 'M4A1-S' },
  { id: 'awp', name: 'AWP' },
  { id: 'usp-s', name: 'USP-S' },
  { id: 'glock-18', name: 'Glock-18' },
  { id: 'desert-eagle', name: 'Desert Eagle' },
  { id: 'famas', name: 'FAMAS' },
  { id: 'galil-ar', name: 'Galil AR' },
  { id: 'sg-553', name: 'SG 553' },
  { id: 'aug', name: 'AUG' },
  { id: 'ssg-08', name: 'SSG 08' },
];

export const FINISHES: string[] = [
  'Factory New',
  'Minimal Wear',
  'Field-Tested',
  'Well-Worn',
  'Battle-Scarred',
];
