
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { GeneratorForm } from './components/GeneratorForm';
import { ImageDisplay } from './components/ImageDisplay';
import { generateSkinImage } from './services/geminiService';
import { WEAPONS, FINISHES } from './constants';
import type { FormState } from './types';

const App: React.FC = () => {
  const [formState, setFormState] = useState<FormState>({
    weapon: WEAPONS[0].id,
    finish: FINISHES[0],
    description: 'A futuristic skin with glowing blue circuits and a carbon fiber texture.',
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    setGeneratedImage(null);
    setError(null);
    
    const selectedWeapon = WEAPONS.find(w => w.id === formState.weapon);
    if (!selectedWeapon) {
      setError("Invalid weapon selected.");
      setIsLoading(false);
      return;
    }

    const prompt = `A high-quality, detailed concept art of a Counter-Strike 2 weapon skin for the ${selectedWeapon.name}. The skin has a "${formState.finish}" finish and features the following design: "${formState.description}". The image should be a professional, portfolio-quality side view of the weapon on a clean, dark studio background, highlighting the skin's texture and details.`;

    try {
      const imageB64 = await generateSkinImage(prompt);
      setGeneratedImage(`data:image/png;base64,${imageB64}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [formState]);

  return (
    <div className="min-h-screen bg-cs-darker bg-cover bg-center" style={{backgroundImage: 'url(https://picsum.photos/seed/cs2bg/1920/1080?blur=5)'}}>
      <div className="min-h-screen bg-black bg-opacity-70 backdrop-blur-sm">
        <Header />
        <main className="container mx-auto p-4 md:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-cs-dark bg-opacity-80 p-6 rounded-lg border border-cs-light-gray shadow-xl">
              <GeneratorForm 
                formState={formState}
                setFormState={setFormState}
                onSubmit={handleGenerate}
                isLoading={isLoading}
              />
            </div>
            <div className="bg-cs-dark bg-opacity-80 p-6 rounded-lg border border-cs-light-gray shadow-xl flex items-center justify-center min-h-[400px] lg:min-h-0">
              <ImageDisplay 
                isLoading={isLoading}
                generatedImage={generatedImage}
                error={error}
              />
            </div>
          </div>
          <footer className="text-center text-gray-500 mt-8 text-xs">
            <p>CS2 AI Skin Concept Generator. This tool is for artistic inspiration and does not create in-game items.</p>
            <p>Counter-Strike is a trademark of Valve Corporation. This project is not affiliated with Valve Corporation.</p>
          </footer>
        </main>
      </div>
    </div>
  );
};

export default App;
