
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="py-6 px-4 md:px-8 text-center bg-black bg-opacity-20">
      <h1 className="font-orbitron text-3xl md:text-5xl font-bold tracking-wider uppercase">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-cs-orange to-yellow-300">CS2</span>
        <span className="text-gray-300"> AI Skin Generator</span>
      </h1>
      <p className="mt-2 text-sm md:text-base text-cs-blue">
        Generate your dream weapon skin concepts
      </p>
    </header>
  );
};
