
import React from 'react';
import { WEAPONS, FINISHES } from '../constants';
import type { FormState } from '../types';

interface GeneratorFormProps {
  formState: FormState;
  setFormState: React.Dispatch<React.SetStateAction<FormState>>;
  onSubmit: () => void;
  isLoading: boolean;
}

const FormLabel: React.FC<{ children: React.ReactNode; htmlFor: string }> = ({ children, htmlFor }) => (
  <label htmlFor={htmlFor} className="block mb-2 text-sm font-bold text-cs-blue uppercase tracking-wider">
    {children}
  </label>
);

const SelectInput: React.FC<{ id: string; value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; children: React.ReactNode }> = ({ id, value, onChange, children }) => (
    <select
        id={id}
        value={value}
        onChange={onChange}
        className="w-full bg-cs-gray border border-cs-light-gray text-gray-200 rounded-md p-3 focus:ring-2 focus:ring-cs-orange focus:border-cs-orange transition duration-200"
    >
        {children}
    </select>
);


export const GeneratorForm: React.FC<GeneratorFormProps> = ({ formState, setFormState, onSubmit, isLoading }) => {
  const handleChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-6">
      <div>
        <FormLabel htmlFor="weapon">Select Weapon</FormLabel>
        <SelectInput id="weapon" name="weapon" value={formState.weapon} onChange={handleChange}>
          {WEAPONS.map(weapon => (
            <option key={weapon.id} value={weapon.id}>{weapon.name}</option>
          ))}
        </SelectInput>
      </div>

      <div>
        <FormLabel htmlFor="finish">Select Finish</FormLabel>
        <SelectInput id="finish" name="finish" value={formState.finish} onChange={handleChange}>
          {FINISHES.map(finish => (
            <option key={finish} value={finish}>{finish}</option>
          ))}
        </SelectInput>
      </div>

      <div>
        <FormLabel htmlFor="description">Skin Description</FormLabel>
        <textarea
          id="description"
          name="description"
          rows={6}
          className="w-full bg-cs-gray border border-cs-light-gray text-gray-200 rounded-md p-3 focus:ring-2 focus:ring-cs-orange focus:border-cs-orange transition duration-200 resize-y"
          placeholder="e.g., An elegant marble skin with gold veins..."
          value={formState.description}
          onChange={handleChange}
        />
      </div>

      <div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full font-orbitron font-bold text-lg text-white bg-cs-orange rounded-md p-4 transition-all duration-300 ease-in-out hover:bg-yellow-500 hover:shadow-glow-orange disabled:bg-cs-light-gray disabled:cursor-not-allowed disabled:shadow-none flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating Concept...
            </>
          ) : (
            'Generate Skin Concept'
          )}
        </button>
      </div>
    </form>
  );
};
