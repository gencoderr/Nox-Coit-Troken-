
import React from 'react';

interface ImageDisplayProps {
  isLoading: boolean;
  generatedImage: string | null;
  error: string | null;
}

const Placeholder: React.FC = () => (
    <div className="text-center text-gray-400">
        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-20 w-20 text-cs-light-gray" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <h3 className="mt-4 text-lg font-orbitron font-semibold text-gray-300">Your Skin Concept Will Appear Here</h3>
        <p className="mt-1 text-sm">Fill out the form and click generate to see the magic happen.</p>
    </div>
);

const LoadingSpinner: React.FC = () => (
    <div className="text-center">
        <div className="relative inline-block">
            <div className="w-24 h-24 border-4 border-cs-blue rounded-full animate-spin border-t-transparent"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-cs-orange font-orbitron font-bold">
                AI
            </div>
        </div>
        <p className="mt-4 font-semibold text-lg animate-pulse">Generating your masterpiece...</p>
    </div>
);

const ErrorDisplay: React.FC<{ message: string }> = ({ message }) => (
    <div className="text-center text-red-400 border-2 border-red-500 bg-red-900 bg-opacity-30 p-4 rounded-lg">
        <h3 className="font-bold text-lg">Generation Failed</h3>
        <p className="text-sm">{message}</p>
    </div>
);


export const ImageDisplay: React.FC<ImageDisplayProps> = ({ isLoading, generatedImage, error }) => {
    if (isLoading) {
        return <LoadingSpinner />;
    }
    if (error) {
        return <ErrorDisplay message={error} />;
    }
    if (generatedImage) {
        return (
            <div className="w-full flex flex-col items-center space-y-4">
                <img src={generatedImage} alt="Generated CS2 skin concept" className="rounded-lg shadow-2xl max-w-full h-auto border-2 border-cs-orange" />
                <a
                    href={generatedImage}
                    download="cs2-skin-concept.png"
                    className="w-full sm:w-auto text-center font-orbitron font-bold text-base text-cs-darker bg-cs-blue rounded-md py-2 px-6 transition-all duration-300 ease-in-out hover:bg-cyan-300 hover:shadow-glow-blue"
                >
                    Download Concept
                </a>
                 <p className="text-xs text-gray-500 text-center mt-2">
                    Note: This is an AI-generated concept image and cannot be used directly in-game.
                </p>
            </div>
        );
    }
    return <Placeholder />;
};
