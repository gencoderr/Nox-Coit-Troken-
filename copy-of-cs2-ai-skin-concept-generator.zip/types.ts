
export interface Weapon {
  id: string;
  name: string;
}

export interface FormState {
  weapon: string;
  finish: string;
  description: string;
}
